list=[5,3,8,1,0,4]
def range_list(list):
    min=list[0]
    max=list[0]
    for i in list:
        if min>i:
            min=i
        if max<i:
            max=i
    print(min, max)    
    return max-min
print(f"The range of the list is: {range_list(list)}")

