string = input("Enter the string: ")
def char_count(a):
    word=0
    dict = {}
    for i in a:
        if i in dict:
            dict[i] += 1
        else:
            dict[i] = 1
    char=max(dict, key=dict.get)
    return char, dict[char]

char, count = char_count(string)
print(f"{char} with {count} is maximum number of times occured.")
