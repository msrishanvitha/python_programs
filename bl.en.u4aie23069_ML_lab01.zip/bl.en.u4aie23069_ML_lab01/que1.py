list=[2,7,4,1,3,6]
def count_list_sum(list):
    n=0
    for i in list:
        for j in list:
            if i+j==10:
                n+=1
    return n
print(f"The number of pairs with sum is 10 are: {count_list_sum(list)} ")


