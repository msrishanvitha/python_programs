import numpy as np
size=int(input("Enter size of square matrix:"))
power=int(input("Enter a number to power with the matrix:"))
def matrix_formation(s=size):
    A=np.zeros((s,s),dtype=int)
    for i in range(0,s):
        for j in range(0,s):
            print("Enter the number:")
            b=int(input())
            A[i,j]=b
    return A
A=matrix_formation(size)
print(A)
print(A**power)
